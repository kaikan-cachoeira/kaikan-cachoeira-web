export { default as PerfilPage } from "./pages/PerfilPage";
